package info.rekayasa.check_internet_connection;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
